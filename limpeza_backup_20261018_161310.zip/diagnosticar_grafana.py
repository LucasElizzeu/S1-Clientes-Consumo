"""Diagnóstico local sem exibir credenciais ou o corpo das respostas."""
import asyncio
import os
import re
from urllib.parse import urlsplit
from dotenv import dotenv_values
from velosonet.config import ROOT, load_settings
from velosonet.grafana import GrafanaClient


def address(value):
    try:
        u = urlsplit(value or '')
        host = u.hostname or '(sem host)'
        port = f':{u.port}' if u.port else ''
        return f'{u.scheme}://{host}{port}{u.path}'
    except ValueError:
        return '(endereço inválido)'


async def main():
    prior = os.getenv('GRAFANA_URL')
    settings = load_settings()
    saved = dotenv_values(ROOT / '.env').get('GRAFANA_URL')
    print('Arquivo .env:', ROOT / '.env')
    print('URL no arquivo:', address(saved))
    print('URL efetiva:', address(os.getenv('GRAFANA_URL')))
    print('GRAFANA_URL já existia no processo antes de carregar .env:', prior is not None)
    print('Org efetiva:', '2' if os.getenv('GRAFANA_ORG_ID') == '2' else 'ausente ou diferente de 2')
    print('Autenticação:', 'token' if os.getenv('GRAFANA_TOKEN') else ('usuário/senha' if os.getenv('GRAFANA_USER') else 'ausente'))
    client = GrafanaClient()
    try:
        uid = settings.bbus[0].grafana['dashboard_uid']
        for label, path in [('Saúde', '/api/health'), ('Dashboard', f'/api/dashboards/uid/{uid}')]:
            response = await client.http.get(path)
            print(label, '| URL requisitada:', address(str(response.request.url)))
            print('HTTP:', response.status_code, '| Content-Type:', response.headers.get('content-type', 'ausente'))
            print('Redirecionamento:', response.is_redirect)
            try:
                data = response.json()
                print('JSON válido:', True, '| objeto dashboard:', isinstance(data, dict) and 'dashboard' in data)
            except ValueError:
                print('JSON válido:', False, '| parece HTML:', response.text.lstrip().lower().startswith(('<!doctype html', '<html')))
                # Só identifique assinaturas conhecidas; nunca imprima conteúdo da página.
                body = response.text.lower()
                for name, marker in [('Grafana', 'grafana'), ('página de login', 'type="password"'), ('proxy nginx', '<title>welcome to nginx')]:
                    print('Assinatura ' + name + ':', marker in body)
    finally:
        await client.close()


if __name__ == '__main__':
    asyncio.run(main())
