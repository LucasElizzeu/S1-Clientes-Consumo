"""Exporta a configuração dos seis painéis, sem credenciais de acesso ao Grafana."""
import asyncio
import json
from velosonet.config import ROOT, load_settings
from velosonet.grafana import GrafanaClient, _walk_panels

async def main():
    settings = load_settings()
    client = GrafanaClient()
    try:
        uid = settings.bbus[0].grafana['dashboard_uid']
        dash = await client.dashboard(uid)
        expected = {139, 358, 359, 377, 378, 384}
        panels = []
        for panel in _walk_panels(dash.get('panels')):
            if panel.get('id') in expected:
                panels.append({k: panel[k] for k in ('id','title','type','datasource','targets','fieldConfig','options','transformations') if k in panel})
        found = {p['id'] for p in panels}
        if found != expected:
            raise RuntimeError('Painéis ausentes: ' + str(sorted(expected-found)))
        out = ROOT / 'data' / 'samples' / 'grafana_paineis.json'
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps({'uid': uid, 'datasource': dash.get('datasource'), 'panels': panels}, ensure_ascii=False, indent=2), encoding='utf-8')
        print('Salvo em:', out)
    finally:
        await client.close()

if __name__ == '__main__':
    asyncio.run(main())
