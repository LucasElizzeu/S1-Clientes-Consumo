"""Consulta apenas Grafana; não conecta às BBUs e não envia relatórios."""
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo
from velosonet.config import load_settings
from velosonet.grafana import GrafanaClient

async def main():
    settings = load_settings()
    client = GrafanaClient()
    failed = False
    try:
        for bbu in settings.bbus:
            spec = dict(bbu.grafana, metric='valor do painel Grafana')
            try:
                value = await client.panel_value(spec)
                stamp = datetime.fromtimestamp(value['ts'], ZoneInfo(settings['timezone']))
                print(f"BBU {bbu.id} | painel {spec['panel_id']} | {value['mbps']:.3f} Mb/s | dado de {stamp:%d/%m/%Y %H:%M:%S}")
            except Exception as exc:
                failed = True
                print(f'BBU {bbu.id} | FALHA | {type(exc).__name__}: {exc}')
    finally:
        await client.close()
    return int(failed)

if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))
