"""Copie para a pasta que contém velosonet/ e execute com o Python do projeto.
Coleta real e relatório local; sem envio ao Telegram. BBU 5 sem conexão.
"""
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo

from velosonet.config import ROOT, load_settings, setup_logging
from velosonet.app import App
from velosonet.db import Database
from velosonet.errors import BbuUnavailable


async def main():
    settings = load_settings()
    setup_logging()
    print('Modo local: nenhum relatório será enviado ao Telegram.')
    print('BBU 5 será marcada INDISP., sem tentativa de conexão.')
    print('Grafana:', 'habilitado' if settings.get('grafana_enabled', True) else 'desabilitado (não será validado)')
    settings.raw['telegram_enabled'] = False
    tag = datetime.now(ZoneInfo(settings['timezone'])).strftime('%Y%m%d_%H%M%S_%f')
    app = App(settings)
    app.db.c.close()
    app.db = Database(ROOT / 'data' / 'test_reports' / f'{tag}.sqlite')

    async def unavailable(_command):
        raise BbuUnavailable('BBU 5 sem acesso: ignorada neste teste')

    try:
        await app.start()
        if 5 in app.sessions:
            app.sessions[5].run_mml = unavailable
        await app.routine_b()
        run = app.db._x('SELECT * FROM runs ORDER BY id DESC LIMIT 1').fetchone()
        if run is None or run['finished_at'] is None:
            print('FALHA: relatório não foi concluído.')
            return 1
        for row in app.db._x('SELECT * FROM measurements WHERE run_id=? ORDER BY bbu_id', (run['id'],)).fetchall():
            print(f"BBU {row['bbu_id']}: 4G={row['users_4g']} | 5G={row['users_5g']} | Mb/s={row['traffic_mbps']} | estado={row['state']}")
            if row['errors'] != '[]':
                print('  detalhes:', row['errors'])
        print('PNG:', run['png_path'])
        print('Resumo:\n' + run['caption'])
        print('Relatório salvo localmente; nenhum envio ao Telegram foi executado.')
        print('Este teste não valida o agendador contínuo; Grafana só estará validado se houver valores recentes e corretos.')
        return 0
    finally:
        await app.stop()
        app.db.c.close()


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))
